#! /bin/bash

echo '{"library":[' > movieLibrary.json
cat movie_titles.txt | sed -e 's/\(.*\) +++$+++ \(.*\) +++$+++ \(.*\) +++$+++ \(.*\) +++$+++ \(.*\) +++$+++ \(.*\)/{"movie":"\2", "year":"\3", "rating":"\4", "genre":\6},/g'  >> movieLibrary.json
echo ']}' >> movieLibrary.json

