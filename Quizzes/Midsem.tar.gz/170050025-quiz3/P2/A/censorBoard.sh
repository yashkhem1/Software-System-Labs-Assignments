#! /bin/bash

file=$1
cuss=$2
list=$(cat $cuss)
echo $list
i=0

for word in $list
do
	echo $word
	if [[ $i == 0 ]]; then
		echo hello
		echo $i
		out=$(sed -e "s/\(\W\)$word\(\W\)/\1bleep\2/Ig" $file)
		let i=$i+1
	else
		echo hey
		out=$(echo "$out"|sed -e "s/\(\W\)$word\(\W\)/\1bleep\2/Ig")
		let i=$i+1
	fi
	
done

echo "$out" > censoredConv.txt
