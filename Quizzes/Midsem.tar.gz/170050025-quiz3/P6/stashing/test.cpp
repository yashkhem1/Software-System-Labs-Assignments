
bool test_add_one(int a, int b){
	return (b - a) == 1;
}

bool test_add_zero(int a, int b){
	return (b - a) == 0;
}