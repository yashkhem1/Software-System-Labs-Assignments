#include <iostream>

#include "test.cpp"

int main(int argc, char const *argv[])
{
	int i = 0;

	int ip1 = i+1;
	
	std::cout << test_add_one(i, ip1) << std::endl;
}