<!DOCTYPE html>
<html lang="en">

<head>
  <title>Yash Khemchandani</title>
  <meta charset="utf-8">
  <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="icon" href="logo.png" type="image/x-icon">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Dancing Script">
 <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Gabriela">
 <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Lora">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Rochester">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Spirax">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Bellefair">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Annie Use Your Telescope">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Sue Ellen Francisco">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Elsie Swash Caps">

  <style>
  .fa {
  padding: 20px;
  font-size: 30px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  margin: 10px 5px;
}

.fa:hover {
    opacity: 0.7;
}

a{
  text-decoration: none;
}
/*.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}*/

</style>
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="50" style="background-color: #cccccc">


<!-- Navigation Bar that  is fixed on top -->
<nav class="navbar navbar-inverse navbar-fixed-top" data-offset-top="197">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      <li><a href="./index.php">Home</a></li>
      <li><a href="./academics.html">Academics</a></li>
      <li><a href="https://cse.iitb.ac.in/~anshuln/team.html">CS 251</a></li>
      <li><a href="projects.html"> Projects Undertaken </a></li>
      <li class="active"><a href="./contact.php">Contact</a></li>
      <li><a href="feedback.php"> Reviews </a> </li>
    </ul>
  </div>
</nav>

<div class="jumbotron" style="text-align: center">
  <h1> Contact Me </h1>
</div>

<div class="container" >
  <div style="box-shadow:4px 8px 8px; background-color: #eeeeee">
  <div class="row">
    <div class="col-xs-5 col-xs-offset-1" style="font-size: large; text-align: left;" >
      <br><br>
      <h3> <i> Yash Khemchandani </i> </h3>
      <br>
      <strong> Email: </strong> <i> yashkhem1@gmail.com </i> <br>
      <strong> Address: </strong> <i> Hostel 3, IIT Bombay, Powaii, Mumbai </i>
    <br>
    <br>
    <p> <strong> Follow me on :  </strong> <br>

      <a href="https://facebook.com/yash.khemchandani" style="text-decoration: none;"> <i class="fa fa-facebook" style="font-size:44px"></i> </a>
      <a href="https://twitter.com/yashkhem2" style="text-decoration: none;"><i class="fa fa-twitter" style="font-size:44px" ></i></a>
      <a href="https://github.com/yashkhem1" style="text-decoration: none; color: black;" ><i class="fa fa-github" style="font-size:44px" href="github.com/yashkhem1"></i> </a></p>
    </div>
    <div class="col-xs-4 col-xs-offset-2">
      <img src="./contact.jpeg"  class="img-responsive">
    </div>
  </div>
</div>
</div>

<br>
<br>
<br>
<br>

<div class="jumbotron" style="text-align: center; color: black; background-color: #eeeeee !important" >
    <h1> Feedback </h1>
</div>


 <div class="panel panel-default" style="background-color: #dedede ; margin-top: 30px;">
  <div class="panel-body">
  <h4>
  <form action="put_comments.php" method="POST">
  <div class="form-group" style="font-size: x-large;">
    <label for="name">Name: </label>
    <br>
    <br>
    <input placeholder="Enter your name" type="text" class="form-control" id="name" name="name" required>
    <br>
  </div>
  <div class="form-group" style="font-size: x-large;">
    <label for="comments">Comments: </label>
    <br>
    <br>
    <textarea placeholder="What's on your mind" type="text" class="form-control" id="comments" name="comments" required></textarea>
    <br>
    <div align="center">
    <button type="submit" class="btn btn-default" name="submit" style="background-color: #ababab; color: black;"> <strong> Submit </strong></button>
  </div>
</div>
</form>
</h4>
</div>
</div>



</body>
</html>
