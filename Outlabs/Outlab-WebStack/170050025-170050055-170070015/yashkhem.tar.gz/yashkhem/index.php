<!DOCTYPE html>
<html lang="en">
<head>
  <title>Yash Khemchandani</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="icon" href="logo.png" type="image/x-icon">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Dancing Script">
 <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Gabriela">
 <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Lora">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Rochester">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Spirax">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Bellefair">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Annie Use Your Telescope">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Sue Ellen Francisco">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Elsie Swash Caps">

  <!-- Centering the carousel -->
  <style>
  .carousel-inner > .item > img {
  margin: auto;
  height: 1000px;
  }

 </style>


</head>

<body data-spy="scroll" data-target=".navbar" data-offset="50" style="background-color: #eeeeee">

<div class="container" style="width: 100%;">
<img class="img-responsive" src="./home.JPG" >
</div>
<!-- Navigation Bar that  is fixed on top -->
<nav class="navbar navbar-inverse navbar-fixed-top" data-offset-top="197">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      <li class="active"><a href="./index.php">Home</a></li>
      <li><a href="./academics.html">Academics</a></li>
      <li><a href="https://cse.iitb.ac.in/~anshuln/team.html">CS 251</a></li>
      <li><a href="projects.html"> Projects Undertaken </a></li>
      <li><a href="./contact.php">Contact</a></li>
      <li><a href="feedback.php"> Reviews </a> </li>
    </ul>
  </div>
</nav>


<div class="well" align="center" style="background: #dddddd;font-family: Gabriella;">
   <h1> Hey Stalker! </h1>
   <p style="font-family: Lora; font-size: x-large; text-align: center;"> How did you happen to tumble upon my home page?<br>
  Wait, don't click the back button yet. <br>
  Now that you have come here, take some time to know me.</p>
  <br>
  <br>
  <h3 style="font-family: Lora;"> Needless to say you already know my name! <br>
  But since it is my home page, I need to mention it. </h3>
  <h1 style="font-family: Dancing Script; "> <i> Yash Khemchandani  </i></h1>
  <h3 data-toggle="modal" data-target="#Biography" style="color:blue; font-family: Lora;"> (travel enthusiast, food lover and an anti-loner) </h3>
  <br>
  <br>
  <h4> (Before you go further down, take a look at some of my cringy pics) </h4>
</div>
<!--Well displaying my information -->


<!-- <div  class="jumbotron" style="
      font-family: helvetica;
      background-color: #6666ff;
      color: #ffffff;
      text-align: center">
  <h1>Home</h1>
  <p>Hey, how come you tumbled upon my webpage? <br>
  Well, now that you have, get some time to know me :P</p>
</div> -->

<!-- Modal -->
<div id="Biography" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">About Me</h4>
      </div>
      <div class="modal-body">
        <p style="text-align: center; font-family: Lora;" > First of all, 50 points for unlocking this hidden feature </p>
        <p>
        <p style="font-family: Lora;" > I am a fun-loving person who likes to hang out with friends. <br> And by hangout I don't mean just sitting together or going for a walk. <br> I like to go to movies, malls, amusement parks and all kinds of stuff. <br> Android Development is love. And so is G.O.T <br>
        Valar Morghulis </p>
      </div>
      <div class="modal-footer">
        <button type="button" style="background-color: red" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- Carousel -->

<div id="myCarousel" class="carousel slide" data-ride="carousel" style="background-color: >
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    <li data-target="#myCarousel" data-slide-to="3"></li>
    <li data-target="#myCarousel" data-slide-to="4"></li>
    <li data-target="#myCarousel" data-slide-to="5"></li>
    <li data-target="#myCarousel" data-slide-to="6"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">

    <div class="item">
      <img src="profile.JPG" alt="Creepy Me" class="img-responsive">
    </div>

    <div class="item">
      <img src="mummy.jpg" alt="Creepy Me" class="img-responsive">
    </div>

    <div class="item active">
      <img src="sarthak.jpg" alt="Friend" class="img-responsive">
    </div>

    <div class="item">
      <img src="childhood.jpeg" alt="Childhood Buddies" class="img-responsive">
    </div>



    <div class="item">
      <img src="staring.JPG" alt="Me Oogling" class="img-responsive">
    </div>

    <div class="item">
      <img src="nikarpit.jpg" alt="Best Pals" class="img-responsive">
    </div>

  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<!--
  <div class="container">
  <h2>Dynamic Tabs</h2>
  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Home</a></li>
    <li><a data-toggle="tab" href="#menu1">Menu 1</a></li>
    <li><a data-toggle="tab" href="#menu2">Menu 2</a></li>
    <li><a data-toggle="tab" href="#menu3">Menu 3</a></li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      <h3>HOME</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    </div>
    <div id="menu1" class="tab-pane fade">
      <h3>Menu 1</h3>
      <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
    </div>
    <div id="menu2" class="tab-pane fade">
      <h3>Menu 2</h3>
      <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
    </div>
    <div id="menu3" class="tab-pane fade">
      <h3>Menu 3</h3>
      <p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
    </div>
  </div>
</div>

-->

<div class="container" style="width: 100%; height: 300px; margin: 15px; background-color: #dddddd">
 <ul class="nav nav-tabs" style="background-color: #dddddd">
 <li class="active">
 <a href="#Interests" data-toggle="tab" style="color: black; font-size: xx-large; font-family: Sue Ellen Francisco; " >Academic Interests</a>
 </li>
 <li>
 <a href="#Hobbies" data-toggle="tab" style="color: black; font-size: xx-large; font-family: Sue Ellen Francisco; ">Hobbies</a>
 </li>
 <li>
 <a href="#Ambitions" data-toggle="tab" style="color: black; font-size: xx-large; font-family: Sue Ellen Francisco; ">Ambitions and Goals</a>
 </li>
</ul>

<div class="tab-content" style="width: 100%; height: 200px; background-color: #dddddd">

  <div id="Interests" class="tab-pane fade in active" align="center" style="background: #dddddd ; margin-top: 30px; ;font-family: Sue Ellen Francisco;" >
    <h1> <b> <u> Academic interests </u> </b>  </h1>
    <h3>
    <ol type="1" start="1" style="font-family: Lora;">
      <li> Android Development <i> (Apart from debugging) </i> </li>
      <li> Machine Learning </li>
      <li> Image Processing </li>
      <li> Big Data Analysis </li>
    </ol>
  </h3>
  </div>


  <div id="Hobbies" class="tab-pane fade in" align="center" style="background:#dddddd;  font-family: Sue Ellen Francisco;" >
    <h1> <b> <u> Hobbies </u> </b> </h1>
    <h3>
    <ol type="1" start="1" style="font-family: Lora;">
      <li> Watching good movies </li>
      <li> F.R.I.E.N.D.S and  G.O.T </li>
      <li> Playing Badminton </li>
      <li> Gymming <i> (Not apparent from my physique though) </i> </li>
    </ol>
  </h3>

  </div>


  <div id="Ambitions" class="tab-pane fade in" align="center" style="background:#dddddd;  font-family: Sue Ellen Francisco;" >
    <h1> <b> <u> My Ambitions and Goals </u> </b> </h1>
    <h3 style="font-family: Lora;">
        There is no particular list of my ambitions and goals. <br>
        No one knows what turn their life might take. <br>
        But in the end I aim for being a better human being. <br>


    </h3>

  </div>
</div>
</div>



<br>
<div class="well" align="center" style=" text-align: center; font-size: x-large; background: grey; color: black; right: 0; align-self: right;">
<?php

/* counter */
$datei = fopen("numberOfHits.txt","r");

$count = fgets($datei,1000);
fclose($datei);
$count=$count + 1 ;
echo "This page has got $count views";

$datei = fopen("numberOfHits.txt","w");
fwrite($datei, $count);
fclose($datei);

?>

</div>

</body>
</html>
