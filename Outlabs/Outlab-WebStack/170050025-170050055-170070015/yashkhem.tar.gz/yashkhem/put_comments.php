<!DOCTYPE html>
<html lang="en">
<head>
  <title>Yash Khemchandani</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="icon" href="logo.png" type="image/x-icon">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Dancing Script">
 <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Gabriela">
 <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Lora">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Rochester">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Spirax">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Bellefair">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Annie Use Your Telescope">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Sue Ellen Francisco">
  <link rel="stylesheet"
  href="https://fonts.googleapis.com/css?family=Elsie Swash Caps">
  <title>
    Thank You
</title>
</head>


<body data-spy="scroll" data-target=".navbar" data-offset="50" style="background-color: #eeeeee">

<nav class="navbar navbar-inverse navbar-fixed-top" data-offset-top="197">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      <li><a href="./index.php">Home</a></li>
      <li><a href="./academics.html">Academics</a></li>
      <li><a href="https://cse.iitb.ac.in/~anshuln/team.html">CS 251</a></li>
      <li><a href="projects.html"> Projects Undertaken </a></li>
      <li><a href="./contact.php">Contact</a></li>
      <li class="active"><a href="feedback.php"> Reviews </a> </li>
    </ul>
  </div>
 </nav>


	<div class="panel panel-default" style="margin-top: 70px">
  <div class="panel-body" style="font-family: Lora ; font-size: xx-large;">Thank you for your comment <strong>

<?php
$first=$_POST["name"];
$comm=$_POST["comments"];
echo $first;
$file=fopen("comments.txt","a");
fwrite($file,"<br> <div class=\"panel panel-default\"> <div class=\"panel-body\" style=\"background-color: Lora;\">".$comm."<br> ---".$first."</div></div>");
fclose($file);
?>
</strong>
</div>
</div>
</body>
</html>
