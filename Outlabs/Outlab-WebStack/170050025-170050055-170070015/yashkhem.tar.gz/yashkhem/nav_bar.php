
<!DOCTYPE html>
<html>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- Black with white text -->
<nav class="navbar navbar-inverse navbar-fixed-top" data-offset-top="197">
<div class="container-fluid">
<ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="./home.php">   Home  </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">  About Me  </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="./projects">  Projects Undertaken  </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="./academics.php">  Academics  </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">  CS 251  </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#"><p>  Contact  </p></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="./feedback.php">  Feedback  </a>
    </li>
  </ul> </div></nav>
<head>
    <title></title>
</head>
<body>

</body>
</html>
